//
//  Slots_AppApp.swift
//  Slots_App
//
//  Created by HKIS on 31/10/2024.
//

import SwiftUI

@main
struct Slots_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
